package com.example.expenseapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
