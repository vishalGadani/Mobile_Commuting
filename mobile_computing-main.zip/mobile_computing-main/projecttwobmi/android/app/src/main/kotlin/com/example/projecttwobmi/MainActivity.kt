package com.example.projecttwobmi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
